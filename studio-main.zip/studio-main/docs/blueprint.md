# **App Name**: HealthHub

## Core Features:

- Health Article Summarizer: Provide a summarization of an article using the URL of the provided healthcare document. AI tool analyzes the document and extracts the key information and presents it in an easily understandable format.
- Repository Exploration: Enable users to explore a GitHub repository of healthcare materials.
- Keyword Highlighting: Highlight the keywords and concepts identified by the AI within the displayed summaries.
- Article Sharing: Allow users to share the health summaries or original URLs of articles.

## Style Guidelines:

- Primary color: Soft blue (#64B5F6) to evoke trust and tranquility.
- Background color: Light gray (#F5F5F5) for a clean, readable interface.
- Accent color: Teal (#26A69A) to highlight key elements and calls to action.
- Body and headline font: 'Inter' sans-serif, for clear and modern readability.
- Use a consistent set of minimalist icons related to healthcare topics.
- Maintain a clean and spacious layout with clear visual hierarchy to enhance user experience.
- Use subtle transitions and animations to provide feedback and guide users through the app.