
import fs from 'fs/promises';
import path from 'path';

export async function getSensorData() {
  const filePath = path.join(process.cwd(), 'data.json');
  try {
    const fileContent = await fs.readFile(filePath, 'utf-8');
    const lines = fileContent.trim().split('\n');
    const data = lines.map(line => {
        try {
            return JSON.parse(line);
        } catch (e) {
            return null;
        }
    }).filter(item => item !== null);
    return data;
  } catch (error) {
    console.error('Error reading or parsing data.json:', error);
    return [];
  }
}
