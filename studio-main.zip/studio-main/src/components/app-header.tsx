import { HeartPulse } from 'lucide-react';
import Link from 'next/link';

export default function AppHeader() {
  return (
    <header className="border-b bg-card shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 text-xl font-bold text-foreground">
            <HeartPulse className="h-7 w-7 text-primary" />
            <span className="font-headline">Health Monitor</span>
          </Link>
        </div>
      </div>
    </header>
  );
}
