import { Monitor, User } from 'lucide-react';
import Link from 'next/link';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import AppHeader from '@/components/app-header';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <AppHeader />
      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Health Monitoring Dashboard
          </h1>
          <p className="mt-6 text-lg leading-8 text-muted-foreground">
            Choose your view to see the sensor data.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          <Link href="/doctor">
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-6 w-6 text-primary" />
                  <span>Doctor View</span>
                </CardTitle>
                <CardDescription>
                  View and analyze patient sensor data.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-center items-center bg-muted h-32 rounded-md">
                  <p className="text-sm text-muted-foreground">Go to Doctor Dashboard</p>
                </div>
              </CardContent>
            </Card>
          </Link>
          <Link href="/patient">
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-6 w-6 text-primary" />
                  <span>Patient View</span>
                </CardTitle>
                <CardDescription>
                  See your personal health data.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-center items-center bg-muted h-32 rounded-md">
                  <p className="text-sm text-muted-foreground">Go to Patient Dashboard</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
      </main>
    </div>
  );
}
