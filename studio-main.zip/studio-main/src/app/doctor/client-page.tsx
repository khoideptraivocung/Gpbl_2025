
'use client';

import { useState, useEffect } from 'react';
import { Area, AreaChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import AppHeader from '@/components/app-header';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

// Mock data for one patient, the other will come from data.json
const initialPatientDataTemplate = {
  'patient-1': {
    name: 'John Doe',
    data: [], // This will be filled from data.json
    checklist: {
      morning: {
        sleepTime: 7.5,
        medication: true,
        breakfast: true,
        pain: false,
        dizziness: false,
        mood: 4,
      },
      noon: {
        medication: false,
        lunch: true,
        pain: false,
        dizziness: false,
        mood: 5,
      },
      night: {
        medication: true,
        dinner: true,
        pain: true,
        dizziness: false,
        mood: 3,
      },
    },
  },
  'patient-2': {
    name: 'Jane Smith',
    data: [
        {"time": "00:00", "pulse": 65, "temperature": 36.8, "humidity": 48},
        {"time": "01:00", "pulse": 66, "temperature": 36.7, "humidity": 47},
        {"time": "02:00", "pulse": 67, "temperature": 36.7, "humidity": 48},
        {"time": "03:00", "pulse": 68, "temperature": 36.8, "humidity": 49},
        {"time": "04:00", "pulse": 69, "temperature": 36.9, "humidity": 50},
        {"time": "05:00", "pulse": 70, "temperature": 36.8, "humidity": 48},
        {"time": "06:00", "pulse": 72, "temperature": 37.0, "humidity": 47},
        {"time": "07:00", "pulse": 78, "temperature": 37.1, "humidity": 50},
        {"time": "08:00", "pulse": 82, "temperature": 37.2, "humidity": 53},
        {"time": "09:00", "pulse": 85, "temperature": 37.3, "humidity": 55},
        {"time": "10:00", "pulse": 83, "temperature": 37.2, "humidity": 54},
        {"time": "11:00", "pulse": 80, "temperature": 37.1, "humidity": 52},
        {"time": "12:00", "pulse": 78, "temperature": 37.2, "humidity": 51},
    ],
    checklist: {
      morning: {
        sleepTime: 8,
        medication: true,
        breakfast: true,
        pain: false,
        dizziness: false,
        mood: 5,
      },
      noon: {
        medication: true,
        lunch: true,
        pain: false,
        dizziness: false,
        mood: 4,
      },
      night: {
        medication: true,
        dinner: true,
        pain: false,
        dizziness: true,
        mood: 2,
      },
    },
  },
};

export default function DoctorClientPage({ initialSensorData }: { initialSensorData: any[] }) {
  const [patientData, setPatientData] = useState(() => {
    const data = JSON.parse(JSON.stringify(initialPatientDataTemplate));
    data['patient-1'].data = initialSensorData.slice(0, 13);
    return data;
  });
  const [selectedPatientId, setSelectedPatientId] = useState('patient-1');

  useEffect(() => {
    let dataIndex = 13;
    const interval = setInterval(() => {
      setPatientData(prevData => {
        const newPatientData = JSON.parse(JSON.stringify(prevData));

        // Update patient-1 from data.json
        if (dataIndex < initialSensorData.length) {
            const patient1 = newPatientData['patient-1'];
            const newPoint = initialSensorData[dataIndex];
            patient1.data = [...patient1.data.slice(1), newPoint];
            dataIndex++;
        }


        // Update patient-2 with random data
        const patient2 = newPatientData['patient-2'];
        const lastPoint2 = patient2.data[patient2.data.length - 1] || { time: new Date().toISOString(), pulse: 70, temperature: 36.8, humidity: 50 };
        const newPoint2 = {
            time: new Date(new Date("1970-01-01T" + lastPoint2.time + "Z").getTime() + 60 * 60 * 1000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
            pulse: 70 + Math.round((Math.random() - 0.5) * 20),
            temperature: 25 + (Math.random() - 0.5),
            humidity: 50 + Math.round((Math.random() - 0.5) * 10),
        }
        patient2.data = [...patient2.data.slice(-11), newPoint2];

        return newPatientData;
      });
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, [initialSensorData]);

  const selectedPatient = patientData[selectedPatientId];
  const patientList = Object.keys(patientData).map(id => ({ id, name: patientData[id].name }));

  const checklistData = selectedPatient.checklist;

  const renderChecklistItem = (label: string, value: boolean | number | string) => (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">
        {typeof value === 'boolean' ? (value ? 'Yes' : 'No') : value}
        {label === 'Sleep Time (hours)' ? ' hrs' : ''}
        {label === 'Mood (1-5)' ? '/5' : ''}
      </span>
    </div>
  );


  return (
    <div className="flex flex-col min-h-screen">
      <AppHeader />
      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Doctor's Dashboard</h1>
            <div className="w-64">
                <Select value={selectedPatientId} onValueChange={setSelectedPatientId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a patient" />
                  </SelectTrigger>
                  <SelectContent>
                    {patientList.map(patient => (
                        <SelectItem key={patient.id} value={patient.id}>{patient.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Pulse Rate</CardTitle>
                <CardDescription>Real-time patient pulse data (BPM)</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={selectedPatient.data}>
                    <defs>
                      <linearGradient id="colorPulse" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis domain={[400, 450]} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}/>
                    <Legend />
                    <Area type="monotone" dataKey="pulse" stroke="hsl(var(--primary))" fill="url(#colorPulse)" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Room Temperature</CardTitle>
                <CardDescription>Real-time patient room temperature data (°C)</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={selectedPatient.data}>
                    <defs>
                      <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--chart-3))" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="hsl(var(--chart-3))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis domain={[24, 28]}/>
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}/>
                    <Legend />
                    <Area type="monotone" dataKey="temperature" stroke="hsl(var(--chart-3))" fill="url(#colorTemp)" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Room Humidity</CardTitle>
                <CardDescription>Real-time patient room humidity (%)</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={selectedPatient.data}>
                     <defs>
                      <linearGradient id="colorHumidity" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis domain={[48, 54]}/>
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}/>
                    <Legend />
                    <Area type="monotone" dataKey="humidity" stroke="hsl(var(--chart-2))" fill="url(#colorHumidity)" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
             <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Daily Health Checklist</CardTitle>
                <CardDescription>Patient-reported health status for today.</CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full" defaultValue="morning">
                  <AccordionItem value="morning">
                    <AccordionTrigger>Morning</AccordionTrigger>
                    <AccordionContent>
                      <div className="grid gap-2">
                        {renderChecklistItem('Sleep Time (hours)', checklistData.morning.sleepTime)}
                        {renderChecklistItem('Morning Medication', checklistData.morning.medication)}
                        {renderChecklistItem('Breakfast', checklistData.morning.breakfast)}
                        {renderChecklistItem('Body Pain', checklistData.morning.pain)}
                        {renderChecklistItem('Dizziness', checklistData.morning.dizziness)}
                        {renderChecklistItem('Mood (1-5)', checklistData.morning.mood)}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="noon">
                    <AccordionTrigger>Noon</AccordionTrigger>
                    <AccordionContent>
                       <div className="grid gap-2">
                        {renderChecklistItem('Lunchtime Medication', checklistData.noon.medication)}
                        {renderChecklistItem('Lunch', checklistData.noon.lunch)}
                        {renderChecklistItem('Body Pain', checklistData.noon.pain)}
                        {renderChecklistItem('Dizziness', checklistData.noon.dizziness)}
                        {renderChecklistItem('Mood (1-5)', checklistData.noon.mood)}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="night">
                    <AccordionTrigger>Night</AccordionTrigger>
                    <AccordionContent>
                      <div className="grid gap-2">
                        {renderChecklistItem('Evening Medication', checklistData.night.medication)}
                        {renderChecklistItem('Dinner', checklistData.night.dinner)}
                        {renderChecklistItem('Body Pain', checklistData.night.pain)}
                        {renderChecklistItem('Dizziness', checklistData.night.dizziness)}
                        {renderChecklistItem('Mood (1-5)', checklistData.night.mood)}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

    