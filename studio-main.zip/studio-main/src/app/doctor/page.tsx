
import { getSensorData } from '@/lib/sensor-data';
import DoctorClientPage from './client-page';

export default async function DoctorView() {
  const initialSensorData = await getSensorData();
  return <DoctorClientPage initialSensorData={initialSensorData} />
}
