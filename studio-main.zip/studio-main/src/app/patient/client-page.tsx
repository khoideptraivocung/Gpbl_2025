
'use client';

import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import AppHeader from '@/components/app-header';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const checklistData = {
  morning: {
    sleepTime: 7.5,
    medication: true,
    breakfast: true,
    pain: false,
    dizziness: false,
    mood: 4,
  },
  noon: {
    medication: false,
    lunch: true,
    pain: false,
    dizziness: false,
    mood: 5,
  },
  night: {
    medication: true,
    dinner: true,
    pain: true,
    dizziness: false,
    mood: 3,
  },
};


export default function PatientClientPage({ initialSensorData }: { initialSensorData: any[] }) {
  const [data, setData] = useState(() => initialSensorData.slice(0, 5));

  useEffect(() => {
    let dataIndex = 5;
    const interval = setInterval(() => {
      if (dataIndex < initialSensorData.length) {
        setData(prevData => {
          const newPoint = initialSensorData[dataIndex];
          dataIndex++;
          return [...prevData.slice(1), newPoint]; // Keep the last 5 data points
        });
      }
    }, 3000); // Update every 3 seconds

    return () => clearInterval(interval);
  }, [initialSensorData]);

  const renderChecklistItem = (label: string, value: boolean | number | string) => (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">
        {typeof value === 'boolean' ? (value ? 'Yes' : 'No') : value}
        {label === 'Sleep Time (hours)' ? ' hrs' : ''}
        {label === 'Mood (1-5)' ? '/5' : ''}
      </span>
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen">
      <AppHeader />
      <main className="flex-grow container mx-auto px-4 py-8 md:py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">My Health Data</h1>
          <div className="grid grid-cols-1 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Daily Health Checklist</CardTitle>
                <CardDescription>Your reported health status for today.</CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full" defaultValue="morning">
                  <AccordionItem value="morning">
                    <AccordionTrigger>Morning</AccordionTrigger>
                    <AccordionContent>
                      <div className="grid gap-2">
                        {renderChecklistItem('Sleep Time (hours)', checklistData.morning.sleepTime)}
                        {renderChecklistItem('Morning Medication', checklistData.morning.medication)}
                        {renderChecklistItem('Breakfast', checklistData.morning.breakfast)}
                        {renderChecklistItem('Body Pain', checklistData.morning.pain)}
                        {renderChecklistItem('Dizziness', checklistData.morning.dizziness)}
                        {renderChecklistItem('Mood (1-5)', checklistData.morning.mood)}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="noon">
                    <AccordionTrigger>Noon</AccordionTrigger>
                    <AccordionContent>
                      <div className="grid gap-2">
                        {renderChecklistItem('Lunchtime Medication', checklistData.noon.medication)}
                        {renderChecklistItem('Lunch', checklistData.noon.lunch)}
                        {renderChecklistItem('Body Pain', checklistData.noon.pain)}
                        {renderChecklistItem('Dizziness', checklistData.noon.dizziness)}
                        {renderChecklistItem('Mood (1-5)', checklistData.noon.mood)}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="night">
                    <AccordionTrigger>Night</AccordionTrigger>
                    <AccordionContent>
                      <div className="grid gap-2">
                        {renderChecklistItem('Evening Medication', checklistData.night.medication)}
                        {renderChecklistItem('Dinner', checklistData.night.dinner)}
                        {renderChecklistItem('Body Pain', checklistData.night.pain)}
                        {renderChecklistItem('Dizziness', checklistData.night.dizziness)}
                        {renderChecklistItem('Mood (1-5)', checklistData.night.mood)}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>My Pulse Rate</CardTitle>
                <CardDescription>Your real-time pulse data (beats per minute).</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart
                    data={data}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis domain={[400, 450]} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}/>
                    <Legend />
                    <Line type="monotone" dataKey="pulse" stroke="hsl(var(--primary))" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Room Temperature</CardTitle>
                <CardDescription>Your real-time room temperature data (°C).</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart
                    data={data}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis domain={[24, 28]} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}/>
                    <Legend />
                    <Line type="monotone" dataKey="temperature" stroke="hsl(var(--chart-3))" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Room Humidity</CardTitle>
                <CardDescription>Your real-time room humidity (%).</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart
                    data={data}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis domain={[48, 54]} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}/>
                    <Legend />
                    <Line type="monotone" dataKey="humidity" stroke="hsl(var(--chart-2))" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );

    