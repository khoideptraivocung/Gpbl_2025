
import { getSensorData } from '@/lib/sensor-data';
import PatientClientPage from './client-page';

export default async function PatientView() {
    const initialSensorData = await getSensorData();
    return <PatientClientPage initialSensorData={initialSensorData} />;
}
