# IoT Sensor Data API

This is a simple REST API for storing and retrieving IoT sensor data.

## Features

- Store sensor data (e.g., temperature, humidity, lux)
- Retrieve all sensor data
- Retrieve data for a specific sensor
- Filter data by metric (e.g., temperature)
- Rate limiting (60 requests per minute per sensor)
- API key authentication

## Installation

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-username/iot_demo.git
    cd iot_demo
    ```

2.  **Create and activate a conda environment:**
    ```bash
    conda create --name iot_demo python=3.9
    conda activate iot_demo
    ```

3.  **Install the dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

4.  **Set the API key:**
    ```bash
    export API_KEY="your-secret-api-key"
    ```

5.  **Run the application:**
    ```bash
    python app.py
    ```

The application will start on `http://127.0.0.1:5000`.

## Web Interface

To view the latest sensor data in near real-time, open your web browser and navigate to `http://127.0.0.1:5000`.

## API Endpoints

### Add Sensor Data

- **URL:** `/data`
- **Method:** `POST`
- **Headers:**
  - `X-API-KEY`: Your secret API key
- **Body:**
  ```json
  {
    "sensor_id": "sensor1",
    "metric": "temperature",
    "value": 25.5
  }
  ```
- **Success Response:**
  - **Code:** 201 CREATED
  - **Content:**
    ```json
    {
      "id": 1,
      "sensor_id": "sensor1",
      "timestamp": "2025-08-31T12:00:00",
      "metric": "temperature",
      "value": 25.5
    }
    ```
- **Error Response:**
  - **Code:** 400 BAD REQUEST
  - **Content:**
    ```json
    {
      "error": "Invalid data. sensor_id, metric and value are required."
    }
    ```
  - **Code:** 401 UNAUTHORIZED
  - **Content:**
    ```json
    {
      "message": "Invalid or missing API key"
    }
    ```
  - **Code:** 429 TOO MANY REQUESTS

### Get All Sensor Data

- **URL:** `/data`
- **Method:** `GET`
- **Success Response:**
  - **Code:** 200 OK
  - **Content:**
    ```json
    [
      {
        "id": 1,
        "sensor_id": "sensor1",
        "timestamp": "2025-08-31T12:00:00",
        "metric": "temperature",
        "value": 25.5
      },
      {
        "id": 2,
        "sensor_id": "sensor1",
        "timestamp": "2025-08-31T12:01:00",
        "metric": "humidity",
        "value": 60.2
      }
    ]
    ```

### Get Latest Sensor Data by Sensor ID

- **URL:** `/data/<sensor_id>`
- **Method:** `GET`
- **Query Parameters:**
  - `metric` (optional): Filter by a specific metric (e.g., `temperature`).
- **Success Response:**
  - **Code:** 200 OK
  - **Content:**
    ```json
    {
      "id": 1,
      "sensor_id": "sensor1",
      "timestamp": "2025-08-31T12:00:00",
      "metric": "temperature",
      "value": 25.5
    }
    ```
- **Error Response:**
  - **Code:** 404 NOT FOUND
  - **Content:**
    ```json
    {
      "error": "No data found for this sensor."
    }
    ```
