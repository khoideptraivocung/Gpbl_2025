
import pandas as pd
from datetime import datetime, timedelta
import matplotlib
matplotlib.use('Agg') # Use a non-interactive backend
import matplotlib.pyplot as plt
import io
import os
import google.generativeai as genai
from app import app, db, SensorData

def generate_summary():
    """
    Query data from all sensors for the past day, downsample to a 1-minute grid, 
    generate a line plot, save it, and then use the Gemini API to summarize the plot.
    """
    try:
        with app.app_context():
            # 1. Query data from the last 24 hours
            one_day_ago = datetime.utcnow() - timedelta(days=1)
            recent_data = SensorData.query.filter(SensorData.timestamp >= one_day_ago).all()

            if not recent_data:
                print("No data available for the last 24 hours to generate a summary.")
                return

            # 2. Convert to Pandas DataFrame and downsample
            df = pd.DataFrame([d.to_dict() for d in recent_data])
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df.set_index('timestamp', inplace=True)

            # Pivot and resample
            df_pivot = df.pivot_table(index=df.index, columns=['sensor_id', 'metric'], values='value')
            df_resampled = df_pivot.resample('1T').mean()

            # 3. Generate plot
            fig, ax = plt.subplots(figsize=(12, 6))
            df_resampled.plot(ax=ax)
            ax.set_title('Sensor Data (1-min average) - Last 24 Hours')
            ax.set_xlabel('Time')
            ax.set_ylabel('Value')
            plt.tight_layout()

            # Save plot to a file
            plot_filename = "summary_plot.png"
            plt.savefig(plot_filename, format='png')
            print(f"Plot saved to {plot_filename}")

            # Save plot to an in-memory buffer for the API
            buf = io.BytesIO()
            plt.savefig(buf, format='png')
            buf.seek(0)
            
            # 4. Get summary from Gemini
            GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', 'AIzaSyBRn0TcysvRWOmWJENtgAmHwipMjELIcd0')
            genai.configure(api_key=GEMINI_API_KEY)
            model = genai.GenerativeModel('gemini-1.5-flash-latest')
            
            image_part = {
                "mime_type": "image/png",
                "data": buf.getvalue()
            }
            
            prompt = "Summarize the trends and any anomalies in the attached sensor data plot. The plot shows sensor values over the last 24 hours. Please provide a concise summary of what you see. Trả lời bằng tiếng việt"
            
            response = model.generate_content([prompt, image_part])
            
            buf.close()
            plt.close(fig)

            print("\n--- AI Summary ---")
            print(response.text)
            print("--------------------")

    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == '__main__':
    generate_summary()
