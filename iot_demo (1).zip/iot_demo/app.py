from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

# --- Configuration ---
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///iot_data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
API_KEY = os.environ.get('API_KEY', 'your-secret-api-key') # Use environment variable in production
GEMINI_API_KEY = 'AIzaSyBRn0TcysvRWOmWJENtgAmHwipMjELIcd0' # TODO move to env variable later in prod

# --- Database ---
db = SQLAlchemy(app)

class SensorData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sensor_id = db.Column(db.String(50), nullable=False)
    timestamp = db.Column(db.DateTime, server_default=db.func.now())
    metric = db.Column(db.String(50), nullable=False)
    value = db.Column(db.Float, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'sensor_id': self.sensor_id,
            'timestamp': self.timestamp.isoformat(),
            'metric': self.metric,
            'value': self.value
        }

# --- Rate Limiting ---
limiter = Limiter(
    get_remote_address,
    app=app,
)

# --- Authentication ---
def require_api_key(f):
    def decorated(*args, **kwargs):
        if request.headers.get('X-API-KEY') and request.headers.get('X-API-KEY') == API_KEY:
            return f(*args, **kwargs)
        else:
            return jsonify({"message": "Invalid or missing API key"}), 401
    return decorated

# --- API Endpoints ---
@app.route('/data', methods=['POST'])
@require_api_key
@limiter.limit("60/second", key_func = lambda: request.json.get('sensor_id'))
def add_data():
    data = request.get_json()
    if not data or 'sensor_id' not in data or 'metric' not in data or 'value' not in data:
        return jsonify({'error': 'Invalid data. sensor_id, metric and value are required.'}), 400

    new_data = SensorData(
        sensor_id=data['sensor_id'],
        metric=data['metric'],
        value=data['value']
    )
    db.session.add(new_data)
    db.session.commit()
    return jsonify(new_data.to_dict()), 201

@app.route('/data', methods=['GET'])
def get_all_data():
    all_data = SensorData.query.order_by(SensorData.timestamp.asc()).all()
    data_by_sensor = {}
    for data_point in all_data:
        sensor_id = data_point.sensor_id
        if sensor_id not in data_by_sensor:
            data_by_sensor[sensor_id] = []
        data_by_sensor[sensor_id].append(data_point.to_dict())
    
    return jsonify(data_by_sensor)

@app.route('/data/<string:sensor_id>', methods=['GET'])
def get_sensor_data(sensor_id):
    metric = request.args.get('metric')
    query = SensorData.query.filter_by(sensor_id=sensor_id)
    if metric:
        query = query.filter_by(metric=metric)

    latest_data = query.order_by(SensorData.timestamp.desc()).first()

    if not latest_data:
        return jsonify({'error': 'No data found for this sensor.'}), 404
    return jsonify(latest_data.to_dict())





@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)