import requests
import random
import time
import threading

API_URL = "http://127.0.0.1:5000/data"
API_KEY = "your-secret-api-key"  # Make sure this matches the API_KEY in your app.py
SENSOR_IDS = [f"sensor_{i}" for i in range(1, 100)]
METRICS = ["temperature", "humidity", "lux"]

def simulate_sensor(sensor_id):
    while not stop_event.is_set():
        try:
            metric = random.choice(METRICS)
            value = round(random.uniform(0, 100), 2)
            data = {
                "sensor_id": sensor_id,
                "metric": metric,
                "value": value
            }
            headers = {
                "X-API-KEY": API_KEY
            }
            response = requests.post(API_URL, json=data, headers=headers)
            if response.status_code == 201:
                print(f"Successfully sent data for {sensor_id}: {data}")
            else:
                print(f"Failed to send data for {sensor_id}. Status code: {response.status_code}, Response: {response.text}")
        except requests.exceptions.RequestException as e:
            print(f"An error occurred: {e}")

        time.sleep(random.uniform(0.5, 2.0)) # Simulate real-time updates

if __name__ == "__main__":
    stop_event = threading.Event()
    threads = []

    for sensor_id in SENSOR_IDS:
        thread = threading.Thread(target=simulate_sensor, args=(sensor_id,)) 
        threads.append(thread)
        thread.start()

    try:
        while True:
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\nStopping sensor simulation...")
        stop_event.set()
        for thread in threads:
            thread.join()
        print("All sensors stopped.")
